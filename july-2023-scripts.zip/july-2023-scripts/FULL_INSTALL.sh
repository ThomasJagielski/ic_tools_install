#!/bin/sh

chmod +x ./00_install_tools.sh
chmod +x ./01_install_pdk.sh
chmod +x ./02_post_install_config.sh
chmod +x ./03_configure_xyce.sh
chmod +x ./04_install_act.sh
chmod +x ./05_app_icons.sh

./00_install_tools.sh
./01_install_pdk.sh
./02_post_install_config.sh
./03_configure_xyce.sh
./04_install_act.sh
./05_app_icons.sh
