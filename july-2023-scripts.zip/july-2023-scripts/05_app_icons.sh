#!/bin/bash

# Xschem
sudo cp ./icons/xschem.desktop /usr/local/share/applications
sudo cp ./icons/xschem-icon.xpm /usr/local/share/pixmaps

# magic
sudo cp ./icons/magic.desktop /usr/local/share/applications
sudo cp ./icons/magic.png /usr/local/share/pixmaps


